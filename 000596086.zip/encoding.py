"""""
NOM: Rocca
PRENOM: Manuel
SECTION: INFO
MATRICULE: 000596086
"""""

from image import Image
from pixel import Pixel

class Encoder:
    """
    Sauvegarde un objet image dans un fichier, sous le format demandé.
    """
    def __init__(self, img, version = 1, **kwargs):
        self.image = img
        self.version = version
        
        self.pixels = self.image.pixels
        self.width = self.image.width
        self.height = self.image.height
        if self.version == 3:
            self.RLE = kwargs["rle"]
            self.depth = kwargs["depth"]
            if self.RLE == "" or self.depth == "":
                raise ValueError("Paramètres manquants")
            #récupération d'une liste de couleurs composant l'image ainsi que leur quantité
            self.occurences_uniques, self.nombre_couleurs_distinctes = self.image.getUniqueColors()
            if self.nombre_couleurs_distinctes * 3 > (2 ** 8 - 15) and self.depth != 24:
                raise ValueError("Impossible d'encoder autant de couleurs différentes dans cette version.")
        self.taille_header = 12 if self.version != 3 else 14 + self.nombre_couleurs_distinctes * 3
    
    
    def save_to(self, path):
        """
        Méthode qui détermine dans quel format enregister.
        """
        with open(path, "wb") as f:
            #écriture header (12 bytes)
            f.write(b"ULBMP")
            f.write((self.version).to_bytes(1, "little"))
            f.write((self.taille_header).to_bytes(2, "little"))
            f.write((self.width).to_bytes(2, "little"))
            f.write((self.height).to_bytes(2, "little"))
            
            if self.version == 1:
                self.ecriture_v1(f)
            
            elif self.version == 2:
                self.ecriture_v2(f)
            
            elif self.version == 3:
                self.ecriture_v3(f)
            
            elif self.version == 4:
                self.ecriture_v4(f)


    def ecriture_v1(self, file):
        """
        Ecriture classique, 24 bits par pixel.
        """
        #écriture valeurs pixels en binaire
        for pixel in self.pixels:
            file.write((pixel[0]).to_bytes(1, "little"))
            file.write((pixel[1]).to_bytes(1, "little"))
            file.write((pixel[2]).to_bytes(1, "little"))
        
    def ecriture_v2(self, file):
        """
        Ecriture en RLE (1 bytes spécifiant le nombre de répétitions du pixel qui le suit),
        avec 24 bits par pixel.
        """
        #écriture valeurs pixels en binaire
        current_pix = self.pixels[0]
        pixel_occurrences = 1
        for next_pix in self.pixels[1:]:
            if next_pix == current_pix and pixel_occurrences < 255:
                pixel_occurrences += 1
            else:
                file.write(pixel_occurrences.to_bytes(1, "little"))
                file.write((current_pix[0]).to_bytes(1, "little"))
                file.write((current_pix[1]).to_bytes(1, "little"))
                file.write((current_pix[2]).to_bytes(1, "little"))
                current_pix = next_pix
                pixel_occurrences = 1
        
        file.write((pixel_occurrences).to_bytes(1, "little"))
        file.write((current_pix[0]).to_bytes(1, "little"))
        file.write((current_pix[1]).to_bytes(1, "little"))
        file.write((current_pix[2]).to_bytes(1, "little"))
    

    def ecriture_v3(self, file):
        """
        Ecriture qui prend en compte la profondeur, le RLE (pour les profondeurs 8 et 24)
        ainsi qu'une palette de couleur dans le header.
        """
        #header complété avec profondeur, RLE et palette
        file.write(self.depth.to_bytes(1, "little"))
        file.write(self.RLE.to_bytes(1, "little"))
        
        if self.depth != 24:#pas de palette si depth == 24
            for couleur in self.occurences_uniques:
                file.write((couleur[0]).to_bytes(1, "little"))
                file.write((couleur[1]).to_bytes(1, "little"))
                file.write((couleur[2]).to_bytes(1, "little"))

        #gestion de l'encodage RLE (uniquement profondeurs 8 et 24)   
        if self.RLE:
            current_pix = self.occurences_uniques.index(self.pixels[0])
            pixel_occurrences = 1
            for next_pix in self.pixels[1:]:
                next_pix = self.occurences_uniques.index(next_pix)
                if next_pix == current_pix and pixel_occurrences < 255:
                    pixel_occurrences += 1
                else:
                    file.write(pixel_occurrences.to_bytes(1, "little"))
                    if self.depth == 24:
                        #écriture classique (comme pour la v1 et v2)
                        file.write((self.occurences_uniques[current_pix][0]).to_bytes(1, "little"))
                        file.write((self.occurences_uniques[current_pix][1]).to_bytes(1, "little"))
                        file.write((self.occurences_uniques[current_pix][2]).to_bytes(1, "little"))
                    else:
                        #profondeur 8 bits par pixel avec RLE
                        file.write(current_pix.to_bytes(1, "little"))
                    
                    current_pix = next_pix
                    pixel_occurrences = 1
        
        #écriture sans RLE et des profondeurs < 8
        else:
            byte = self.occurences_uniques.index(self.pixels[0])
            bit_par_byte = self.depth
            compteur = self.depth
            for pix in self.pixels[1:]:
                if bit_par_byte == 8:
                    compteur += 1
                    bit_par_byte = 0
                pix = self.occurences_uniques.index(pix)
                byte = (byte << self.depth) + pix
                bit_par_byte += self.depth
            while bit_par_byte != 8:
                byte = (byte << self.depth) + 0
                bit_par_byte += self.depth
            file.write((byte.to_bytes((compteur), "little")))

    
    def ecriture_v4(self, file):
        """
        Ecriture qui opère en bloc qui ont des identifiants permettant de
        distinguer son type. Le type de bloc change en fonction des différences
        entre un pixel et son antécédent.
        """
        pix_prec = Pixel(0, 0, 0)
        
        for pix_next in self.pixels:
            #identifier le type de blocs
            #récupération des données nécessaires à son encodage
            type_de_bloc, params_bloc = self.calcul_deltas(pix_prec, pix_next)

            if type_de_bloc == "ULBMP_SMALL_DIFF":
                byte = 0
                for delta in params_bloc:
                    byte = (byte << 2) + delta
                file.write(byte.to_bytes(1, "little"))
            
            elif type_de_bloc == "ULBMP_INTERMEDIATE_DIFF":
                byte = (1 << 6) + params_bloc[0]
                for delta in params_bloc[1:]:
                    byte = (byte << 4) + delta
                file.write(byte.to_bytes(2, "big"))
            
            elif "ULBMP_BIG_DIFF" in type_de_bloc:
                if type_de_bloc == "ULBMP_BIG_DIFF_R":
                    byte = 128
                elif type_de_bloc == "ULBMP_BIG_DIFF_G":
                    byte = 144
                elif type_de_bloc == "ULBMP_BIG_DIFF_B":
                    byte = 160
                
                byte = byte + (params_bloc[0] >> 4)
                byte = (byte << 8) + ((params_bloc[0] & 15) << 4) + (params_bloc[1] >> 2)
                byte = (byte << 8) + ((params_bloc[1] & 3) << 6) + (params_bloc[2])
                file.write(byte.to_bytes(3, "big"))

            else:
                file.write((255).to_bytes(1, "little"))
                file.write((pix_next[0]).to_bytes(1, "little"))
                file.write((pix_next[1]).to_bytes(1, "little"))
                file.write((pix_next[2]).to_bytes(1, "little"))
            
            pix_prec = pix_next
    
    
    def calcul_deltas(self, pix1, pix2):
        
        #calcul de tous les deltas
        delta_r = pix2[0] - pix1[0]
        delta_g = pix2[1] - pix1[1]
        delta_b = pix2[2] - pix1[2]
        delta_r_g = delta_r - delta_g
        delta_r_b = delta_r - delta_b
        delta_g_b = delta_g - delta_b
        delta_g_r = delta_g - delta_r
        delta_b_r = delta_b - delta_r
        delta_b_g = delta_b - delta_g

        #type de valeur à encoder
        if -2 <= delta_r <= 1 and -2 <= delta_g <= 1 and -2 <= delta_b <= 1:
            return "ULBMP_SMALL_DIFF", [delta_r + 2, delta_g + 2, delta_b + 2]

        elif -32 <= delta_g <= 31 and -8 <= delta_r_g <= 7 and -8 <= delta_b_g <= 7:
            return "ULBMP_INTERMEDIATE_DIFF", [delta_g + 32, delta_r_g + 8, delta_b_g + 8]
        
        if -128 <= delta_r <= 127 and -32 <= delta_g_r <= 31 and -32 <= delta_b_r <= 31:
            return "ULBMP_BIG_DIFF_R", [delta_r + 128, delta_g_r + 32, delta_b_r + 32]
        
        elif -128 <= delta_g <= 127 and -32 <= delta_r_g <= 31 and -32 <= delta_b_g <= 31:
            return "ULBMP_BIG_DIFF_G", [delta_g + 128, delta_r_g + 32, delta_b_g + 32]
        
        elif -128 <= delta_b <= 127 and -32 <= delta_r_b <= 31 and -32 <= delta_g_b <= 31:
            return "ULBMP_BIG_DIFF_B", [delta_b + 128, delta_r_b + 32, delta_g_b + 32]
        
        else:
            return "ULBMP_NEW_PIXEL", None


        
class Decoder:
    """
    Classe qui lit un fichier de type ULBMP.
    """
    @staticmethod
    def load_from(path):
        """
        Lecture du fichier donné.
        Return d'un objet image. 
        """
        with open(path, "rb") as f:           
            
            #lecture header
            type_fichier = f.read(5)
            if not type_fichier.decode() == "ULBMP":
                raise Exception
            version = int.from_bytes(f.read(1), "little")
            taille_header = int.from_bytes(f.read(2), "little")
            width = int.from_bytes(f.read(2), "little")
            height = int.from_bytes(f.read(2), "little")
            taille_image = width * height
            
            #lecture fichier
            if version == 3:
                PROFONDEUR = int.from_bytes(f.read(1), "little")
                RLE = int.from_bytes(f.read(1), "little")
                
                #gestion du cas où la compression RLE est activée avec une profondeur différente de 8 ou 24
                if RLE == 1 and str(PROFONDEUR) not in "824":
                    raise TypeError("La compression RLE n'est disponible que pour les profondeurs 8 et 24 bits par pixel.")
                
                if PROFONDEUR == 24:
                    pixels = Decoder.lecture_v2(f) if RLE else Decoder.lecture_v1(f)
                else:
                    pixels = Decoder.lecture_v3(f, RLE, taille_header, PROFONDEUR, taille_image)
            elif version == 4:
                pixels = Decoder.lecture_v4(f)
            else:
                pixels = Decoder.lecture_v1(f) if version == 1 else Decoder.lecture_v2(f)
            

            return Image(width, height, pixels)

    #ces méthodes de lecture renvoient toutes une liste de pixel
    @staticmethod
    def lecture_v1(file):
        """
        Lecture de fichier avec une profondeur de 24 bits par pixel.
        """
        pixels = []
        pix = file.read(3)
        while pix:
            red, green, blue = int.from_bytes(pix[0:1], "little"),\
                                int.from_bytes(pix[1:2], "little"),\
                                int.from_bytes(pix[2:3], "little")
            pixels.append(Pixel(red, green, blue))
            pix = file.read(3)
        return pixels
    
    @staticmethod
    def lecture_v2(file):
        """
        Lecture de fichier encodé avec du RLE.
        """
        pixels = []
        pix = file.read(4)
        while pix:
            red, green, blue = int.from_bytes(pix[1:2], "little"),\
                                    int.from_bytes(pix[2:3], "little"),\
                                    int.from_bytes(pix[3:4], "little")
            for _ in range(int.from_bytes(pix[0:1], "little")):
                 pixels.append(Pixel(red, green, blue))
            pix = file.read(4)
        return pixels
    
    @staticmethod
    def lecture_v3(file, RLE, header_size, PROFONDEUR, taille_image):
        """
        Lecture de fichier en tenant compte de sa profondeur d'encodage
        et du RLE.
        """
        #récupération de la palette dans un dictionnaire
        palette = {}
        for i in range((header_size - 14)//3):
            pix = file.read(3)
            red, green, blue = int.from_bytes(pix[0:1], "little"),\
                                int.from_bytes(pix[1:2], "little"),\
                                int.from_bytes(pix[2:3], "little")
            palette[i] = (red, green, blue)
        #décodage des pixels
        pixels = []
        pix = file.read(1)
        while pix:
            #lecture d'un encodage RLE
            if RLE:
                iterations, pix = int.from_bytes(pix[0:1], "little"), int.from_bytes(file.read(1), "little")
                ind_palette = [pix >> i & ((1 << PROFONDEUR) - 1) for i in range(8 - PROFONDEUR, - PROFONDEUR, - PROFONDEUR)]
                ind = ind_palette[0]#le RLE profondeur 24 est géré par lecture_v2 donc il ne peut y avoir une profondeur de 8 uniquement
                                    #la liste ind_palette est donc composée d'un élément unique et je mets cet élément dans la variable
                                    #ind pour rendre le hashing de la palette plus clair
                for _ in range (iterations):
                    pixels.append(Pixel(palette[ind][0], palette[ind][1], palette[ind][2]))
            
            #lecture sans encodage RLE
            else:
                pix = int.from_bytes(pix[0:1], "little")
                ind_palette = [pix >> i & ((1 << PROFONDEUR) - 1) for i in range(8 - PROFONDEUR, - PROFONDEUR, - PROFONDEUR)]
                for indice in ind_palette:
                    r, g, b = palette[indice][0], palette[indice][1], palette[indice][2]
                    pixels.append(Pixel(r, g, b)) if len(pixels) != taille_image else None
            
            pix = file.read(1)

        return pixels
    
    @staticmethod
    def lecture_v4(file):
        """
        Lecture de fichier encodé avec des blocs.
        """
        pixels = []
        pix_ref = [0, 0, 0]
        pix = file.read(1)
        while pix:
            type_bloc = Decoder.analyze_bloc(int.from_bytes(pix, "little"))
            if type_bloc == "ULBMP_NEW_PIXEL":
                pix = Decoder.get_pix_NewPix(file)

            elif type_bloc == "ULBMP_SMALL_DIFF":
                pix = Decoder.get_pix_SmallDiff(int.from_bytes(pix, "little"), pix_ref)
                
            elif type_bloc == "ULBMP_INTERMEDIATE_DIFF":
                #récupération du 2e byte
                pix = pix + file.read(1)
                pix = Decoder.get_pix_InterDiff(pix, pix_ref)
            
            else:
                pix = int.from_bytes(pix + file.read(2), "big")
                pix = Decoder.get_pix_BigDiff(pix, type_bloc, pix_ref)

            pix_ref = [pix[0], pix[1], pix[2]]
            pixels.append(Pixel(pix[0], pix[1], pix[2]))
            pix = file.read(1)
        
        return pixels

    @staticmethod
    def analyze_bloc(byte):
        """
        Cette fonction détermine le type de bloc lu et 
        renvoie ce type.
        """
        if byte == 255:#'0b11111111'
            return "ULBMP_NEW_PIXEL"
        elif byte >> 6 == 0:#'0b00'
            return "ULBMP_SMALL_DIFF"
        elif byte >> 6 == 1:#'0b01'
            return "ULBMP_INTERMEDIATE_DIFF"
        elif byte >> 4 == 8:#'0b1000'
            return "ULBMP_BIG_DIFF_R"
        elif byte >> 4 == 9:#'0b1001'
            return "ULBMP_BIG_DIFF_G"
        elif byte >> 4 == 10:#'0b1010'
            return "ULBMP_BIG_DIFF_B"
    
    #méthodes pour restaurer les pixels
    #renvoient une liste des 3 valeurs du pixel à encoder  
    @staticmethod
    def get_pix_NewPix(file):
        """
        Lecture d'un bloc nouveau pixel.
        """
        R, G, B = int.from_bytes(file.read(1), "little"),\
                  int.from_bytes(file.read(1), "little"),\
                  int.from_bytes(file.read(1), "little")
        return [R, G, B]

    @staticmethod
    def get_pix_SmallDiff(byte, pix_ref):
        """
        Lecture d'un bloc smalldiff.
        """
        #masques => 48 = '0b110000', 12 = '0b1100', 3 = '0b11'
        delta_r, delta_g, delta_b = (byte & 48) >> 4, (byte & 12) >> 2, byte & 3
        R, G, B = delta_r + pix_ref[0] - 2, delta_g + pix_ref[1] - 2, delta_b + pix_ref[2] - 2
        
        return [R, G, B]
        
    @staticmethod
    def get_pix_InterDiff(byte, pix_ref):
        """
        Lecture d'un bloc interdiff.
        """
        byte = int.from_bytes(byte, "big")
        delta_g = (byte & 16128) >> 8 #masque => 16128 = '0b0011111100000000'
        delta_r_g = (byte & 240) >> 4 #masque => 240 = '0b0000000011110000'
        delta_b_g = (byte & 15) #masque => 15 = '0b0000000000001111'
        delta_g = delta_g - 32
        delta_r, delta_b = delta_r_g + delta_g - 8, delta_b_g + delta_g -8
        R, G, B = delta_r + pix_ref[0], delta_g + pix_ref[1], delta_b + pix_ref[2]
        
        return [R, G, B]
    
    @staticmethod
    def get_pix_BigDiff(byte, type_bloc, pix_ref):
        """
        Lecture d'un bloc bigdiff.
        """
        #masque => 1044480 = '0b000011111111000000000000'
        d1 = ((byte & 1044480) >> 12)
        #masque => 4032 = '0b111111000000'
        d2 = ((byte & 4032) >> 6) - 32
        #masque => 63 = '0b111111'
        d3 = (byte & 63) - 32
        d1 = d1 - 128
        d2, d3 = d2 + d1, d3 + d1
        #le dictionnaire n'est peut être pas la voie la plus optimale
        #mais il permet d'obtenir plus de clarté
        canaux = {"ULBMP_BIG_DIFF_R": (d1, d2, d3),
                  "ULBMP_BIG_DIFF_G": (d2, d1, d3),
                  "ULBMP_BIG_DIFF_B": (d2, d3, d1)}
        deltas = canaux.get(type_bloc, (0, 0, 0))
        R, G, B = deltas[0] + pix_ref[0], deltas[1] + pix_ref[1], deltas[2] + pix_ref[2]

        return [R, G, B]