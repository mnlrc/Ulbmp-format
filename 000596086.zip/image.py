"""""
NOM: Rocca
PRENOM: Manuel
SECTION: INFO
MATRICULE: 000596086
"""""

from pixel import Pixel

class Image:
    """
    Classe définissant un objet Image, composé de pixels,
    d'une largeur, d'une hauteur.
    """
    def __init__(self, width, height, pixels):
        
        self.tests_pixels(width, height, pixels)
        
        self.__width = width
        self.__height = height
        self.__pixels = pixels

    #getters
    @property
    def width(self):
        return self.__width
    
    @property
    def height(self):
        return self.__height

    @property
    def pixels(self):
        return self.__pixels
    

    def tests_pixels(self, width, height, pixels):
        """
        Fonction qui vérifie la validité des pixels
        """
        #tous les pixels de la liste doivent être des objets de types Pixel
        if not all(isinstance(pix, Pixel) for pix in pixels):
            raise TypeError("Une image ne peut être composée \
de Pixels uniquement")
        #la longueur de la liste de pixels doit correspondre au format de l'image
        elif len(pixels) != (width * height):
            raise Exception("Le nombre de pixels ne correspond pas à la taille de l'image")
            
    def __getitem__(self, pos):
        x, y = pos
        index = y * self.__width + x
        if index >= len(self.__pixels):
            raise IndexError
        return self.__pixels[index]
    
    def __setitem__(self, pos, pix):
        x, y = pos
        index = y * self.__width + x
        if index >= len(self.pixels):
            raise IndexError
        self.__pixels[index] = pix
    
    def __eq__(self, other):
        return self.pixels == other.pixels
    
    def __repr__(self):
        return f"{self.pixels}"
    
    def getUniqueColors(self):
        """
        Renvoie une liste de couleurs uniques de l'image et leur quantité.
        """
        UniqueColors = set(self.pixels)
        return list(UniqueColors), len(UniqueColors)