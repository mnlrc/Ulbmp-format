"""""
NOM: Rocca
PRENOM: Manuel
SECTION: INFO
MATRICULE: 000596086
"""""


from PySide6.QtWidgets import QMainWindow, QPushButton,\
QHBoxLayout, QWidget, QVBoxLayout, QLabel, QFileDialog, QErrorMessage, QComboBox, QDialog, QCheckBox, QLineEdit
from PySide6.QtGui import QColor, QPixmap, QPainter, QPen, QIcon
from PySide6.QtCore import QCoreApplication

from encoding import Encoder, Decoder


class MainWindow(QMainWindow):
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("ULBMP image viewer")
        self.resize(480, 480)
        
        #strucure 
        self.button_layout = QHBoxLayout()
        self.page_layout = QVBoxLayout()
        self.label = QLabel()
        self.error_message = QErrorMessage()
        self.button_clear = QPushButton("Clear image")

        #objets
        self.btn1 = QPushButton("Load image")
        self.btn1.pressed.connect(self.clicked_button1)
        self.button_layout.addWidget(self.btn1)
        self.img = None
        
        self.btn2 = QPushButton("Save image")
        self.btn2.setEnabled(False)
        self.btn2.pressed.connect(self.clicked_button2)
        self.button_layout.addWidget(self.btn2)

        self.button_clear.setEnabled(False)
        self.button_clear.pressed.connect(self.clicked_button_cls)

        #positionnement des objets
        self.page_layout.addLayout(self.button_layout)
        self.page_layout.addWidget(self.button_clear)
        self.page_layout.addWidget(self.label)
        
        self.widget = QWidget()
        self.widget.setLayout(self.page_layout)
        self.setCentralWidget(self.widget)
    


    def clicked_button1(self):#load
        absolutePath = QFileDialog().getOpenFileName(self, "Choose File", "", "Images (*.ulbmp)")[0]
        if absolutePath != "":
            with open(absolutePath, "rb") as test_file:
                header_ULBMP = test_file.read(5).decode()
            
            #gestion d'un mauvais header
            if header_ULBMP != "ULBMP":
                self.error_message.showMessage("Problem while reading the image: \
                                        'Wrong format: missing 'ULBMP' the header'")
                raise Exception("Le fichier est encodé dans un mauvais format")
            
            #chargement de l'image
            else:
                self.img = Decoder.load_from(absolutePath)
                color_number = self.img.getUniqueColors()[1]
                fileName = absolutePath.split("/")[-1]
                self.display_picture()
                self.setWindowTitle(f"ULBMP image viewer - Fichier: {fileName} - Couleurs Uniques: {color_number}")
                self.btn2.setEnabled(True)
                self.button_clear.setEnabled(True)
            
        else:
            print("Vous n'avez sélectionné aucun fichier.")
       
    def clicked_button2(self):#save
        dialog = DialogSaveTo()
        dialog.exec()
        formatULBMP, depth, RLE, saved_file_name = dialog.ret_values()
        formatULBMP, depth = int(formatULBMP[6]), int(depth)
        if formatULBMP == "":
            pass
        else:
            if formatULBMP == 3:
                kwargs = {"rle" : RLE, "depth" : depth}
                file = Encoder(self.img, formatULBMP, **kwargs)
            else:
                file = Encoder(self.img, formatULBMP)
            path = QFileDialog.getExistingDirectory()
            if path == "":
                print("Aucun répertoire sélectionné.")
            else:
                file.save_to(path + f"/{saved_file_name}.ulbmp")
                print("File saved!")
    
    #clear l'interface
    def clicked_button_cls(self):
        self.label.clear()
        self.button_clear.setEnabled(False)
        self.setWindowTitle("ULBMP image viewer")
    
    #affichage
    def display_picture(self):
        width, height = self.img.width, self.img.height
        pos = 0
        pixmap = QPixmap(width, height)
        painter = QPainter(pixmap)
        pen = QPen()
        for y in range(height):
            for x in range(width):
                pix = self.img.pixels[pos]
                color = QColor(pix[0], pix[1], pix[2])
                pen.setColor(color)
                painter.setPen(pen)
                painter.drawPoint(x, y)
                pos += 1
                
        painter.end()
        
        self.label.setPixmap(pixmap)
        QCoreApplication.processEvents()
        self.adjustSize()
        

class DialogSaveTo(QDialog):
    """
    Classe créant la fenêtre pop-up lors de la sauvegarde
    d'une image.
    """
    def __init__(self):
        super().__init__()

        #objets
        self.setWindowTitle("Save ULBMP file")
        self.drop_menu = QComboBox()
        self.text = QLabel("Choose version: ")
        self.button = QPushButton("Confirm")
        self.dialog_layout = QVBoxLayout()
        self.text_depth = QLabel("Choose depth: ")
        self.rle = QCheckBox("RLE")
        self.depth_choice = QComboBox()
        self.text_input = QLineEdit()
        self.h_layout = QHBoxLayout()
        self.file_name = QLabel("Choose file name: ")

        #placements
        self.dialog_layout.addWidget(self.file_name)
        self.h_layout.addWidget(self.text_input)
        self.h_layout.addWidget(QLabel(".ublmp"))
        self.dialog_layout.addLayout(self.h_layout)
        self.dialog_layout.addWidget(self.text)
        self.dialog_layout.addWidget(self.drop_menu)
        self.dialog_layout.addWidget(self.text_depth)
        self.dialog_layout.addWidget(self.depth_choice)
        self.dialog_layout.addWidget(self.rle)
        self.dialog_layout.addWidget(self.button)

        #actions
        self.depth_choice.hide()
        self.rle.hide()
        self.text_depth.hide()
        self.drop_menu.addItems(["ULBMP 1.0", "ULBMP 2.0", "ULBMP 3.0", "ULBMP 4.0"])
        self.depth_choice.addItems(["1", "2", "4", "8", "24"])
        self.button.pressed.connect(self.button_confirm)
        self.drop_menu.currentTextChanged.connect(self.update_display)
        self.depth_choice.currentTextChanged.connect(self.update_display)

        self.setLayout(self.dialog_layout)
        self.size()
    
    #quitter le dialogue
    def button_confirm(self):
        self.close()

    #update la taille de la page en fonction des formats
    def update_display(self):
        selected_format = self.drop_menu.currentText()
        depth = self.depth_choice.currentText()
        
        if selected_format == "ULBMP 3.0":
            self.depth_choice.show()
            self.rle.show()
            self.text_depth.show()
        else:
            self.depth_choice.hide()
            self.rle.hide()
            self.text_depth.hide()
        
        if depth in ["1", "2", "4"] or selected_format != "ULBMP 3.0":
            self.rle.hide()
        else:
            self.rle.show()
        
        self.adjustSize()
    
    #renvoie les valeurs     
    def ret_values(self):
        return self.drop_menu.currentText(), self.depth_choice.currentText(), self.rle.isChecked(), self.text_input.text()