"""""
NOM: Rocca
PRENOM: Manuel
SECTION: INFO
MATRICULE: 000596086
"""""

class Pixel:
    """
    Classe Pixel correpsondant à un tuple de valeurs,
    R, G, B, chacune ayant une intensité allant de 0 à 255.
    """
    def __init__(self, red = 0, green = 0, blue = 0):
        if not ((0 <= red < 256) and (0 <= green < 256) and (0 <= blue < 256)):
            raise ValueError("L'intensité d'une couleur est limitée entre 0 et 255")
        self.pixel = (red, green, blue)
    
    def __eq__(self, other):
        return self.pixel == other.pixel
    
    def __repr__(self):
        return f"Pixel({self.pixel[0]}, {self.pixel[1]}, {self.pixel[2]})"
    
    def __getitem__(self, key):
        if not (0 <= key < 3):
            raise IndexError("Il n'y a que 3 couleurs dans un Pixel")
        return self.pixel[key]

    def __hash__(self):
        return hash(self.pixel)